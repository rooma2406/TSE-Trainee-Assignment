const url='http://myjson.dit.upm.es/api/bins/6w49';
async function getData(){
    const response= await fetch(url);
    const data = await response.json();
   
    document.getElementById("fname").innerHTML=data.name;
    document.getElementById("role").innerHTML=data.role;
    document.getElementById("contact").innerHTML=data.contact;
    document.getElementById("email").innerHTML=data.email;
    document.getElementById("add").innerHTML=data.address;
    document.getElementById("linkedin").innerHTML=data.linkedin;
}
getData();